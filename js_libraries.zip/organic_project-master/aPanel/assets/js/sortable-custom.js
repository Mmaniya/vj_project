'use strict';
$(function () {
    Sortable.create(draggableMultiple, {
        group: 'draggableMultiple',
        animation: 150
    });
});
