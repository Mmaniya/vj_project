  <!-- Favicon icon -->
    <!-- Google font-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600" rel="stylesheet">

    <!-- Required Fremwork -->
    <link rel="stylesheet" type="text/css" href="<?php echo ADMIN_CSS ?>/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">

    <!-- feather Awesome -->
    <link rel="stylesheet" type="text/css" href="<?php echo ADMIN_ICON ?>/feather/css/feather.css">
    <link rel="stylesheet" type="text/css" href="<?php echo ADMIN_ICON ?>/font-awesome/css/font-awesome.min.css">

    <!-- Notification.css -->
    <link rel="stylesheet" type="text/css" href="<?php echo ADMIN_JS ?>/notification/notification.css">

     <!--forms-wizard css-->
     <link rel="stylesheet" type="text/css" href="<?php echo ADMIN_JS ?>/jquery.steps/jquery.steps.css">

     <link href="<?php echo ADMIN_JS; ?>/alert/sweetalert2.min.css" rel="stylesheet" type="text/css" />

    <!-- Toastr -->
    <link rel="stylesheet" href="<?php echo ADMIN_JS; ?>/toastr/toastr.min.css">
    
    <!-- Data Table Css -->
    <link rel="stylesheet" type="text/css" href="<?php echo ADMIN_CSS ?>/data-table/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo ADMIN_CSS ?>/data-table/css/buttons.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo ADMIN_CSS ?>/data-table/css/responsive.bootstrap4.min.css">

    <!-- Style.css -->
    <link rel="stylesheet" type="text/css" href="<?php echo ADMIN_CSS ?>/style.css">
    <link rel="stylesheet" type="text/css" href="<?php echo ADMIN_CSS ?>/jquery.mCustomScrollbar.css">
    <link rel="stylesheet" type="text/css" href="<?php echo ADMIN_CSS ?>/custom.style.css">
