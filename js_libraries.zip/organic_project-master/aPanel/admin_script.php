    <!-- Required Jquery -->
    <script type="text/javascript" src="<?php echo ADMIN_JS ?>/jquery/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo ADMIN_JS ?>/jquery-ui/jquery-ui.min.js"></script>
    <script type="text/javascript" src="<?php echo ADMIN_JS ?>/popper.js/popper.min.js"></script>
    <script type="text/javascript" src="<?php echo ADMIN_JS ?>/bootstrap/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>

    <!-- jquery slimscroll js -->
    <script type="text/javascript" src="<?php echo ADMIN_JS ?>/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- modernizr js -->
    <script type="text/javascript" src="<?php echo ADMIN_JS ?>/modernizr/modernizr.js"></script>
    <script type="text/javascript" src="<?php echo ADMIN_JS ?>/modernizr/css-scrollbars.js"></script>
    
    <!-- jquery sortable js -->
    <script type="text/javascript" src="<?php echo ADMIN_JS ?>/Sortable/Sortable.js"></script>

      <!-- Masking js -->
     <script type="text/javascript" src="<?php echo ADMIN_JS ?>/form-masking/inputmask.js"></script>
     <script type="text/javascript" src="<?php echo ADMIN_JS ?>/form-masking/jquery.inputmask.js"></script>
     <script type="text/javascript" src="<?php echo ADMIN_JS ?>/form-masking/autoNumeric.js"></script>

    <script src="<?php echo ADMIN_JS ?>/tinymce/js/tinymce.min.js"></script>

    <!-- ALERT BOX -->
    <script src="<?php echo ADMIN_JS ?>/alert/sweetalert2.min.js"></script>      
    <script src="<?php echo ADMIN_JS ?>/alert/sweet-alerts.init.js"></script>
        
    <!-- notification js -->
    <script type="text/javascript" src="<?php echo ADMIN_JS ?>/notification/bootstrap-growl.min.js"></script>

   <!-- i18next.min.js -->
    <script type="text/javascript" src="<?php echo ADMIN_JS ?>/i18next/i18next.min.js"></script>
    <script type="text/javascript" src="<?php echo ADMIN_JS ?>/i18next-xhr-backend/i18nextXHRBackend.min.js"></script>
    <script type="text/javascript" src="<?php echo ADMIN_JS ?>/i18next-browser-languagedetector/i18nextBrowserLanguageDetector.min.js"></script>
    <script type="text/javascript" src="<?php echo ADMIN_JS ?>/jquery-i18next/jquery-i18next.min.js"></script>

    <!--Forms - Wizard js-->
    <script src="<?php echo ADMIN_JS ?>/jquery.cookie/jquery.cookie.js"></script>
    <script src="<?php echo ADMIN_JS ?>/jquery.steps/jquery.steps.js"></script>
    <script src="<?php echo ADMIN_JS ?>/jquery-validation/jquery.validate.js"></script>

    <!-- Validation js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.8.3/underscore-min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
    <script type="text/javascript" src="<?php echo ADMIN_JS ?>/form-validation/validate.js"></script>

    <!-- Custom js -->
    <script type="text/javascript" src="<?php echo ADMIN_JS ?>/pcoded.min.js"></script>
    <script type="text/javascript" src="<?php echo ADMIN_JS ?>/vartical-layout.min.js"></script>
    <script type="text/javascript" src="<?php echo ADMIN_JS ?>/script.min.js"></script> 
    <script type="text/javascript" src="<?php echo ADMIN_JS ?>/common-pages.js"></script> 

     <!-- Custom js -->
     <script type="text/javascript" src="<?php echo ADMIN_JS ?>/default.js"></script>
     <script type="text/javascript" src="<?php echo ADMIN_JS ?>/custom-script-user.js"></script>


