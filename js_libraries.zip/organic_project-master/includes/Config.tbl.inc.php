<?php
    define("TBL_USERS", "tbl_users");
    define("TBL_ADMIN_USERS", "tbl_admin_users");
    define("TBL_APPROVED_USERS", "tbl_approved_uesrs");
?>
